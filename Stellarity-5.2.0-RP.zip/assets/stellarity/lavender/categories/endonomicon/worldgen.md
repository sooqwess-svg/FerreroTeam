```json
{
  "title": "Biomes",
  "icon": "minecraft:end_stone"
}
```
